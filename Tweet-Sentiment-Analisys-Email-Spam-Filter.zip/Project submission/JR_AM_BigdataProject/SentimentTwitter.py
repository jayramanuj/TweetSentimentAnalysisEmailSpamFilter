from twython import Twython
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import matplotlib.pyplot as mplt
import plotly.plotly as py
import plotly.graph_objs as grobj
import numpy as np

#twitter application credentials
TwitterAppKey = 'bv7BsWd0WebclciZicA9ITm4Z'
TwitterAppKeySecret = 'f3cvmayEsf0zcDbk8UA8lHW9sfWMPPmBcqNbjHXzMkyxnB9OKQ'
TwitterAccessToken = '2476976467-qEIJUY7M5G3osvenPibh6jWqqvRBwXsgEZ3T2MP'
TwitterAccessTokenSecret = 'ZdtVFRdj5bHpnjZIcLgqZ8G3XJrNhITZ1NE7OOqr5iWxD'

#global variables counters of the tweets,
positive_counter = 0
negative_counter = 0
neutral_counter = 0

#connection to twitter using twython library
t = Twython(app_key=TwitterAppKey,
                            app_secret= TwitterAppKeySecret,
                            oauth_token= TwitterAccessToken,
                            oauth_token_secret= TwitterAccessTokenSecret)

#selecting perticular genre for getting twitter data: For example "sachin", "Dance", "cricket"
genre = input("Enter key word for finding tweets: ")

#searching the tweets based on keyword
search = t.search(q = genre, lang = 'en', count=100)
tweets = search['statuses']

#processing the tweets

for tweet in tweets:
    print(tweet['text'])
    t = tweet['text']
#sentiment analyzer
    sid = SentimentIntensityAnalyzer()
#checking the polarities of the tweets
    sentiment_tweet = sid.polarity_scores(t)
    positive = sentiment_tweet["pos"]
    negative = sentiment_tweet["neg"]
    neutral = sentiment_tweet["neu"]
    print("------->> TWEET REVIEW \n")
    print("Positive: ", positive , "Negative: ", negative , "Neutral: ", neutral)
    print("******************************************** NEW TWEET *************************************************\n")
#checking that the tweet is positive or negative
    if neutral == 1.0:
        neutral_counter += 1
    else:
        if positive > negative and positive > neutral:
            positive_counter += 1
        elif negative > positive and negative > neutral:
            negative_counter += 1
#considering the neutral tweets as positive tweets and negative based on the following logic
        elif neutral > positive and neutral > negative and positive > negative:
            positive_counter += 1
        elif neutral > positive and neutral > negative and negative > positive:
            negative_counter += 1

print("POSITIVE TWEETS: ", positive_counter)
print("NEGATIVE TWEETS: ", negative_counter)
print("Neutral Tweets:",neutral_counter)

#ploting the data on a bar chart
tweet_numbers  = [positive_counter,negative_counter,neutral_counter]
xaxisobjects  = ('Positive', 'Negative', 'Neutral')
y_pos = np.arange(len(xaxisobjects))
#generating bars
mplt.bar(y_pos, tweet_numbers, align='center', alpha=1)
mplt.xticks(y_pos, xaxisobjects)
#labels assigning
mplt.ylabel('Number of Tweets')
mplt.title('Tweet Sentiments on the keyword : '+ str(genre))
#displaying graph
mplt.show()



