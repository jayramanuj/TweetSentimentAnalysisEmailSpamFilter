import nltk
import random
from nltk.tokenize import TweetTokenizer
from nltk.corpus import stopwords
import string


#email to be tested file opening and fetching data.
TestEmailfobj = open("emailTest.txt", "rb+")
data = TestEmailfobj.read()
TestEmailfobj.close()
data = data.decode(encoding='UTF-8',errors='strict')

#removing punctuations and tokenizing the read data from test email.
punctuations = set(string.punctuation)
test_words = []
tk = TweetTokenizer()
tokenWords = tk.tokenize(data)
wordsWithoutPunctuation = [word for word in tokenWords if word not in punctuations]
filteredWords = [word for word in wordsWithoutPunctuation if word not in stopwords.words('english')]

#reading spam email data
spamEmailfobj = open("spamEmail.txt", "rb+")
data = spamEmailfobj.read()
spamEmailfobj.close()
data = data.decode(encoding='UTF-8',errors='strict')
spamEmails = data.split("*******")


# read genuine email
genuineEmailfobj = open("genuineEmails.txt", "rb+")
data = genuineEmailfobj.read()
genuineEmailfobj.close()
data = data.decode(encoding='UTF-8',errors='strict')
genuineEmails = data.split("*******")
punctuations = set(string.punctuation)

#storage lists
genuineEmailWords = []
spamEmailWords = []
emailTagged = []

# tokenizing the genuine emails
for gEmail in genuineEmails:
    tokenWords = tk.tokenize(gEmail)
    wordsWithoutPunctuation = [word for word in tokenWords if word not in punctuations]
    filterWords = [word for word in wordsWithoutPunctuation if word not in stopwords.words('english')]
    genuineEmailWords += [word for word in filterWords]
    emailTagged.append((filterWords, "Genuine Email"))

# tokenizing the genuine emails.
for sEmail in spamEmails:
    tokenWords = tk.tokenize(sEmail)
    wordsWithoutPunctuation = [word for word in tokenWords if word not in punctuations]
    filter_words = [word for word in wordsWithoutPunctuation if word not in stopwords.words('english')]
    spamEmailWords += [word for word in filter_words]
    emailTagged.append((filter_words, "Spam Email"))

#randomly shuffling
random.shuffle(emailTagged)

# finding the frequencies of the words.
allWords = ([word for word in genuineEmailWords] + [word for word in spamEmailWords])
allWordsFrequencies = nltk.FreqDist(w.lower() for w in allWords)
wordFeaturing = list(allWordsFrequencies)[:1000]

#It takes the words of emails and checks that wordfeaturing contains that perticular word or not
def getEmailFeatures(email):
    document_words = set(email)
    features = {}
    for word in wordFeaturing:
        features['contains({})'.format(word)] = (word in document_words)
    return features

wordFeatureSets = [(getEmailFeatures(e), c) for (e, c) in emailTagged]

#classifying the words based on trainng words.
wordClassifier = nltk.NaiveBayesClassifier.train(wordFeatureSets)

#displaying final results
print("Email result: ", wordClassifier.classify(getEmailFeatures(filteredWords)))
print("Accuracy of checking email is ", nltk.classify.accuracy(wordClassifier, wordFeatureSets[:5]) * 100,"%")
